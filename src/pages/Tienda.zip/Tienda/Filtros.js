import React from 'react';

const Filtros = ({ filtroPrecio, disponible, onChange }) => {
    const handlePrecioChange = (event) => {
        const value = event.target.value.split('-');
        onChange({ min: parseInt(value[0]), max: parseInt(value[1]) }, disponible);
    };

    const handleDisponibleChange = (event) => {
        onChange(filtroPrecio, event.target.checked);
    };

    return (
        <div className="filtros">
            <div>
                <label>Filtrar por precio:</label>
                <input type="range" min="0" max="100" value={`${filtroPrecio.min}-${filtroPrecio.max}`} onChange={handlePrecioChange} />
            </div>
            <div>
                <label>Disponible:</label>
                <input type="checkbox" checked={disponible} onChange={handleDisponibleChange} />
            </div>
        </div>
    );
};

export default Filtros;
