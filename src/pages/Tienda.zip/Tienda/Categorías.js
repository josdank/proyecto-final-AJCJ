import React from 'react';

const Categorias = ({ categoriaSeleccionada, onChange }) => {
    const categorias = ['Snacks', 'Comida', 'Pasteles', 'Enlatados'];

    return (
        <div className="categorias">
            {categorias.map((categoria) => (
                <button
                    key={categoria}
                    className={categoria === categoriaSeleccionada ? 'categoria-activa' : ''}
                    onClick={() => onChange(categoria)}
                >
                    {categoria}
                </button>
            ))}
        </div>
    );
};

export default Categorias;
